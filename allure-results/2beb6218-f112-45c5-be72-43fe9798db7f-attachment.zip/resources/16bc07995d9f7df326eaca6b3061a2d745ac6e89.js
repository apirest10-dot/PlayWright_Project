function loginSuccess() {
  const x = document.getElementById("successMessage");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

function setSuccessAlert(result, emailValue) {
  result.classList.remove('alert-danger');
  result.classList.add('alert-success');

  const prodList = document.getElementById("prooood");
  const loginSection = document.getElementById("loginSection");
  
  prodList.style.display = "block";
  loginSection.remove();

const logoutLISection = `<a id="logout" class="nav-link" href="auth_ecommerce.html"
>Log Out</a
>`;

const logoutLIPlaceholder = document.getElementsByClassName("lgout")[0];

logoutLIPlaceholder.innerHTML = logoutLISection;
}

function setErrorAlert(result) {
  result.classList.remove('alert-success');
  result.classList.add('alert-danger');
  result.innerHTML =
    "Bad credentials! Please try again! Make sure that you've registered.";
}

function checkCredentials() {
  let emailValue = document.loginForm.emailAddress.value;
  let passwordValue = document.loginForm.password.value;
  const result = document.getElementById("message");
  result.classList.add('alert-danger');
  result.style.display = "block";

  if ('admin@admin.com' == emailValue && 'admin123' == passwordValue) {
    setSuccessAlert(result, emailValue);
    return;
  }

  if (localStorage.length == 0) {
    setErrorAlert(result);
    return;
  }

  if (Object.keys(localStorage).includes(emailValue) && localStorage.getItem(emailValue) == passwordValue) {
    setSuccessAlert(result, emailValue);
  } else {
    setErrorAlert(result);
  }
}

function checkCredentialsProductsList() {
  let emailValue = document.loginForm.emailAddress.value;
  let passwordValue = document.loginForm.password.value;
  const result = document.getElementById("message");
  result.classList.add('alert-danger');
  result.style.display = "block";

  if ('admin@admin.com' == emailValue && 'admin123' == passwordValue) {
    setSuccessAlert(result, emailValue);
    return;
  }

  if (localStorage.length == 0) {
    setErrorAlert(result);
    return;
  }

  if (Object.keys(localStorage).includes(emailValue) && localStorage.getItem(emailValue) == passwordValue) {
    setSuccessAlert(result, emailValue);
  } else {
    setErrorAlert(result);
  }
}
